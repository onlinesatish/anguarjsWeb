var app = angular.module('amaApp',['ngRoute']);

app.config(['$routeProvider', function($routeProvider){
    $routeProvider
    // Home
    .when("/", {templateUrl: "templates/contents/home.html", controller: "amaCtrl"})
    // About
    .when("/about", {templateUrl: "templates/contents/about.html", controller: "amaCtrl"})
	//Contact
    .when("/", {templateUrl: "templates/contents/contact.html", controller: "amaCtrl"})
    // 404
    .otherwise("/about", {templateUrl: "templates/contents/404.html", controller: "amaCtrl"})

}]);